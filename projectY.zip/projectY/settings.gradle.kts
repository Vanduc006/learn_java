rootProject.name = "projectY"
